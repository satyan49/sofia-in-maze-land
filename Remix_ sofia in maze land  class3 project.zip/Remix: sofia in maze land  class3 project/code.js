var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["fca4251a-075e-4ae0-9cb9-6db020f1e578"],"propsByKey":{"fca4251a-075e-4ae0-9cb9-6db020f1e578":{"name":"cup","sourceUrl":null,"frameSize":{"x":381,"y":389},"frameCount":1,"looping":true,"frameDelay":12,"version":"VjWAPjqB0ufOs9LlOsReLBWSLGalEjCp","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":381,"y":389},"rootRelativePath":"assets/fca4251a-075e-4ae0-9cb9-6db020f1e578.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//creating the player Sofia
var Sofia = createSprite(20, 25, 18, 18);
Sofia.shapeColor = "orange";
 

//creating the maze walls (wall1 - wall2)
var wall1 = createSprite(10, 70, 100, 20);
wall1.shapeColor = "red";
var wall2 = createSprite(100, 50, 20, 100);
wall2.shapeColor = "red";
var wall3 = createSprite(90, 150, 90, 20);
wall3.shapeColor = "red";
var wall4 = createSprite(150, 10, 90, 20);
wall4.shapeColor = "red";
var wall5 = createSprite(210, 140, 20, 90);
wall5.shapeColor = "red";
var wall6 = createSprite(290, 110, 20, 90);
wall6.shapeColor = "red";
var wall7 = createSprite(350, 150, 90, 20);
wall7.shapeColor = "red";
var wall8 = createSprite(380, 220, 20, 90);
wall8.shapeColor = "red";
var wall9 = createSprite(300, 220, 90, 20);
wall9.shapeColor = "red";
var wall10 = createSprite(350, 280, 90, 20);
wall10.shapeColor = "red";
var wall11 = createSprite(310, 310, 20, 90);
wall11.shapeColor = "red";
var wall12 = createSprite(320, 390, 60, 10);
wall12.shapeColor = "red";
var wall13 = createSprite(10, 300, 100, 20);
wall13.shapeColor = "red";
var wall14 = createSprite(60, 290, 20, 90);
wall14.shapeColor = "red";
var wall15 = createSprite(150, 230, 90, 20);
wall15.shapeColor = "red";
var wall16 = createSprite(80, 370, 20, 60);
wall16.shapeColor = "red";
var wall17 = createSprite(150, 370, 20, 60);
wall17.shapeColor = "red";
var wall18 = createSprite(220, 340, 60, 20);
wall18.shapeColor = "red";
var wall19 = createSprite(240, 310, 20, 60);
wall19.shapeColor = "red";
var wall20 = createSprite(160, 290, 80, 20);
wall20.shapeColor = "red";
  
 
   

//create cup
var cup = createSprite(390, 340, 20, 70);
cup.shapeColor = "yellow";

function draw() {
  //setting the background color to pink
  background("pink");
  createEdgeSprites();
  Sofia.bounceOff(topEdge);
  Sofia.bounceOff(bottomEdge);
  Sofia.bounceOff(leftEdge);
  Sofia.bounceOff(rightEdge);
  Sofia.bounceOff(wall1);
  Sofia.bounceOff(wall2);
  Sofia.bounceOff(wall3);
  Sofia.bounceOff(wall4);
  Sofia.bounceOff(wall5);
  Sofia.bounceOff(wall6);
  Sofia.bounceOff(wall7);
  Sofia.bounceOff(wall8);
  Sofia.bounceOff(wall9);
  Sofia.bounceOff(wall10);
  Sofia.bounceOff(wall11);
  Sofia.bounceOff(wall12);
  Sofia.bounceOff(wall13);
  Sofia.bounceOff(wall14);
  Sofia.bounceOff(wall15);
  Sofia.bounceOff(wall16);
  Sofia.bounceOff(wall17);
  Sofia.bounceOff(wall18);
  Sofia.bounceOff(wall19);
  Sofia.bounceOff(wall20);
  if (keyDown("up")) {
    Sofia.y = Sofia.y-5;
  }
  if (keyDown("down")) {
    Sofia.y = Sofia.y+5;
  }
  if (keyDown("left")) {
    Sofia.x = Sofia.x-5;
  }
  if (keyDown("right")) {
    Sofia.x = Sofia.x+5;
  }
  
  if ( Sofia.isTouching(cup))  
{
  textSize(40);
  stroke("red");
  text("You Win", 200,200);
  }
  


  drawSprites();
  fill("grey");
  textSize(25);
  text("sofia", 30, 30);
  fill("grey");
  textSize(35);
  text("cup", 335, 330);
  
  }






// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
